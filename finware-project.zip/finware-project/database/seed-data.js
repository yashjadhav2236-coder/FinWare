// The exact sample set from the DWM lab practical (5 of each fact/dimension row).
// Numbers here reconcile with the proposal's mockups: total transaction value
// ₹1,18,600, CA session revenue ₹5,495, bank shares 2.7% / 71.6% / 15.2% / 8.4% / 2.0%.

module.exports = {
  cities: [
    { id: 1, name: 'Mumbai' },
    { id: 2, name: 'Pune' },
    { id: 3, name: 'Thane' },
    { id: 4, name: 'Nagpur' },
    { id: 5, name: 'Nashik' }
  ],
  incomeBrackets: [
    { id: 1, label: '10-15 LPA' },
    { id: 2, label: '15-25 LPA' },
    { id: 3, label: '5-10 LPA' },
    { id: 4, label: '25 LPA+' }
  ],
  accountTypes: [
    { id: 1, type: 'Savings' },
    { id: 2, type: 'Current' }
  ],
  bankTypes: [
    { id: 1, type: 'Private' },
    { id: 2, type: 'Public Sector' }
  ],
  users: [
    { id: 'U01', name: 'Rohan Shah', cityId: 1, incomeId: 1, accountTypeId: 1 },
    { id: 'U02', name: 'Priya Nair', cityId: 2, incomeId: 2, accountTypeId: 2 },
    { id: 'U03', name: 'Karan Mehta', cityId: 3, incomeId: 3, accountTypeId: 1 },
    { id: 'U04', name: 'Sneha Iyer', cityId: 4, incomeId: 4, accountTypeId: 1 },
    { id: 'U05', name: 'Aditya Rao', cityId: 5, incomeId: 3, accountTypeId: 1 }
  ],
  banks: [
    { id: 'B01', name: 'HDFC Bank', typeId: 1 },
    { id: 'B02', name: 'ICICI Bank', typeId: 1 },
    { id: 'B03', name: 'SBI', typeId: 2 },
    { id: 'B04', name: 'Axis Bank', typeId: 1 },
    { id: 'B05', name: 'Kotak Mahindra Bank', typeId: 1 }
  ],
  categories: [
    { id: 'C01', name: 'Groceries', group: 'Essential' },
    { id: 'C02', name: 'Salary', group: 'Income' },
    { id: 'C03', name: 'Rent', group: 'Essential' },
    { id: 'C04', name: 'Investment', group: 'Savings' },
    { id: 'C05', name: 'Utilities', group: 'Essential' }
  ],
  cas: [
    { id: 'CA01', name: 'CA Neha Kulkarni' },
    { id: 'CA02', name: 'CA Suresh Iyer' },
    { id: 'CA03', name: 'CA Anjali Deshmukh' }
  ],
  dates: [
    { id: 'D1', date: '2026-04-01', weekday: 'Wednesday', month: 'April', quarter: 'Q1 FY26-27', year: 2026 },
    { id: 'D2', date: '2026-04-02', weekday: 'Thursday', month: 'April', quarter: 'Q1 FY26-27', year: 2026 },
    { id: 'D3', date: '2026-04-03', weekday: 'Friday', month: 'April', quarter: 'Q1 FY26-27', year: 2026 },
    { id: 'D4', date: '2026-04-04', weekday: 'Saturday', month: 'April', quarter: 'Q1 FY26-27', year: 2026 },
    { id: 'D5', date: '2026-04-05', weekday: 'Sunday', month: 'April', quarter: 'Q1 FY26-27', year: 2026 }
  ],
  transactions: [
    { id: 'T001', dateId: 'D1', userId: 'U01', bankId: 'B01', categoryId: 'C01', amount: 3200, type: 'DEBIT' },
    { id: 'T002', dateId: 'D2', userId: 'U02', bankId: 'B02', categoryId: 'C02', amount: 85000, type: 'CREDIT' },
    { id: 'T003', dateId: 'D3', userId: 'U03', bankId: 'B03', categoryId: 'C03', amount: 18000, type: 'DEBIT' },
    { id: 'T004', dateId: 'D4', userId: 'U04', bankId: 'B04', categoryId: 'C04', amount: 10000, type: 'DEBIT' },
    { id: 'T005', dateId: 'D5', userId: 'U05', bankId: 'B05', categoryId: 'C05', amount: 2400, type: 'DEBIT' }
  ],
  caSessions: [
    { id: 'S001', dateId: 'D1', userId: 'U01', caId: 'CA01', fee: 999, status: 'Completed' },
    { id: 'S002', dateId: 'D2', userId: 'U02', caId: 'CA02', fee: 1499, status: 'Completed' },
    { id: 'S003', dateId: 'D3', userId: 'U03', caId: 'CA01', fee: 799, status: 'Scheduled' },
    { id: 'S004', dateId: 'D4', userId: 'U04', caId: 'CA03', fee: 1198, status: 'Completed' },
    { id: 'S005', dateId: 'D5', userId: 'U05', caId: 'CA02', fee: 1000, status: 'Cancelled' }
  ],
  admin: {
    email: 'admin@finware.com',
    password: 'finware2026',
    name: 'Admin',
    role: 'Data Warehouse Administrator'
  }
};
